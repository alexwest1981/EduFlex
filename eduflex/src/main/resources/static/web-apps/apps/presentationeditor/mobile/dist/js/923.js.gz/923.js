/*! For license information please see 923.js.LICENSE.txt */
"use strict";(self.webpackChunkdocumenteditor=self.webpackChunkdocumenteditor||[]).push([[923],{923:function(e,t,u){u.r(t)}}]);